﻿using System;
using System.Linq;

namespace Betail.Models
{
    public class Vaccination
    {
        public int Id { get; set; } // Identifiant unique
        public int AnimalId { get; set; } // Référence à l'animal concerné
        public Animal Animal { get; set; } = null!; // Relation avec le modèle Animal
        public string NomVaccin { get; set; } = string.Empty; // Nom du vaccin
        public DateTime DateVaccination { get; set; } // Date de l'administration du vaccin
        public DateTime? DateRappel { get; set; } // Date prévue pour le rappel (si applicable)
        public string Veterinaire { get; set; } = string.Empty; // Nom du vétérinaire ayant administré le vaccin
        public string Notes { get; set; } = string.Empty; // Informations ou remarques supplémentaires

        /// <summary>
        /// Recherche, filtrage et pagination pour la liste des vaccinations.
        /// </summary>
        /// <param name="query">Query de base (IQueryable)</param>
        /// <param name="search">Texte de recherche</param>
        /// <param name="filter">Filtre par vaccin</param>
        /// <param name="pageNumber">Numéro de page</param>
        /// <param name="pageSize">Taille de page</param>
        /// <returns>Liste paginée des vaccinations</returns>
        public static IQueryable<Vaccination> AppliquerFiltrageEtPagination(
            IQueryable<Vaccination> query,
            string? search = null,
            string? filter = null,
            int pageNumber = 1,
            int pageSize = 10)
        {
            // Appliquer le filtrage
            if (!string.IsNullOrEmpty(filter))
            {
                query = query.Where(v => v.NomVaccin.Contains(filter));
            }

            // Appliquer la recherche
            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(v =>
                    v.Veterinaire.Contains(search) ||
                    v.Notes.Contains(search) ||
                    v.Animal.NumeroPlaque.Contains(search));
            }

            // Tri par défaut : date de vaccination décroissante
            query = query.OrderByDescending(v => v.DateVaccination);

            // Appliquer la pagination
            return query.Skip((pageNumber - 1) * pageSize).Take(pageSize);
        }
    }
}
