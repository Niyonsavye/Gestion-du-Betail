﻿namespace Betail.Models
{
    public class TypeAnimal
    {
        public int Id { get; set; } // Identifiant unique
        public string Name { get; set; } // Nom du type (e.g., "Vache", "Chèvre")
        public string Description { get; set; } // Description facultative

        // Relation avec les animaux
        public ICollection<Animal> Animals { get; set; } = new List<Animal>();
    }
}
