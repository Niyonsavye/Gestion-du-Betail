﻿using System;
using System.Collections.Generic;

namespace Betail.Models
{
    public class Employee
    {
        public int Id { get; set; } // Identifiant unique de l'employé

        public string Nom { get; set; } // Nom complet de l'employé

        public string Adresse { get; set; } // Adresse de l'employé

        public string Telephone { get; set; } // Numéro de téléphone

        public string Role { get; set; } // Rôle ou poste de l'employé (ex : Soigneur, Vétérinaire, Administrateur)

        public decimal SalaireMensuel { get; set; } // Salaire mensuel de l'employé

        public DateTime DateEmbauche { get; set; } // Date d'embauche de l'employé

        public DateTime? DateFinContrat { get; set; } // Date de fin de contrat (si applicable)

        public ICollection<Finance> Transactions { get; set; } // Relation avec les finances (paiement de salaire ou dépenses liées)
    }
}
