﻿using System;

namespace Betail.Models
{
    public class Finance
    {
        public int Id { get; set; } // Identifiant unique de la transaction

        public string TypeTransaction { get; set; } // "Dépense" ou "Revenu"

        public string Categorie { get; set; } // Catégorie de la transaction (ex : Nourriture, Vente d'animaux, Médicaments)

        public decimal Montant { get; set; } // Montant de la transaction

        public DateTime DateTransaction { get; set; } // Date de la transaction

        public string Description { get; set; } // Détails ou commentaires supplémentaires

        // Relation optionnelle avec Animal (si lié à un animal spécifique)
        public int? AnimalId { get; set; } // Clé étrangère vers Animal
        public Animal Animal { get; set; } // Propriété de navigation vers l'Animal
    }
}
