﻿using System;

namespace Betail.Models
{
    public class Traitement
    {
        public int Id { get; set; } // Identifiant unique du traitement

        public int AnimalId { get; set; } // Clé étrangère vers Animal
        public Animal Animal { get; set; } // Propriété de navigation vers l'Animal

        public string TypeTraitement { get; set; } // Type de traitement (ex : Vaccination, Vermifuge, Antibiotique)

        public string Medicament { get; set; } // Médicament utilisé (ex : "Ivermectine")

        public DateTime DateTraitement { get; set; } // Date où le traitement a été administré

        public DateTime? DateProchainTraitement { get; set; } // Date du prochain traitement, si applicable

        public string Notes { get; set; } // Observations ou remarques spécifiques sur le traitement
    }
}
