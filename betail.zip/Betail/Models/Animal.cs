﻿using System;

namespace Betail.Models
{
    public class Animal
    {
        public int Id { get; set; } // Identifiant unique
        public string NumeroPlaque { get; set; } // Numéro de plaque
        public Sexe Sexe { get; set; } // Sexe de l'animal (Mâle/Femelle)
        public DateTime DateNaissance { get; set; } // Date de naissance de l'animal

        // Relation avec TypeAnimal
        public int TypeAnimalId { get; set; } // Clé étrangère vers TypeAnimal
        public TypeAnimal TypeAnimal { get; set; } // Propriété de navigation vers TypeAnimal

        // Propriété calculée : Âge
        public int Age
        {
            get
            {
                var today = DateTime.Today;
                var age = today.Year - DateNaissance.Year;
                if (DateNaissance > today.AddYears(-age)) age--;
                return age;
            }
        }
    }

    // Enum pour le sexe
    public enum Sexe
    {
        Male = 1, // Mâle
        Femelle = 2 // Femelle
    }
}
