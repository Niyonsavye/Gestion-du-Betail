﻿using Betail.Models;

public class Feeding
{
    public int Id { get; set; } // Identifiant unique

    public int AnimalId { get; set; } // Référence à l'animal

    public Animal Animal { get; set; } // Propriété de navigation vers Animal

    public DateTime DateAlimentation { get; set; } // Date d'alimentation

    public string TypeNourriture { get; set; } // Type de nourriture donnée (ex : foin, céréales)

    public decimal Quantite { get; set; } // Quantité de nourriture donnée

    public decimal Couts { get; set; } // Coût de la nourriture donnée
}
