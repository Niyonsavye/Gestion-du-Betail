﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Betail.Data;
using Betail.Models;

namespace Betail.Controllers
{
    public class TraitementsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TraitementsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Traitements
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Traitement.Include(t => t.Animal);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: Traitements/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var traitement = await _context.Traitement
                .Include(t => t.Animal)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (traitement == null)
            {
                return NotFound();
            }

            return View(traitement);
        }

        // GET: Traitements/Create
        public IActionResult Create()
        {
            ViewData["AnimalId"] = new SelectList(_context.Animal, "Id", "Id");
            return View();
        }

        // POST: Traitements/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,AnimalId,TypeTraitement,Medicament,DateTraitement,DateProchainTraitement,Notes")] Traitement traitement)
        {
            if (ModelState.IsValid)
            {
                _context.Add(traitement);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AnimalId"] = new SelectList(_context.Animal, "Id", "Id", traitement.AnimalId);
            return View(traitement);
        }

        // GET: Traitements/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var traitement = await _context.Traitement.FindAsync(id);
            if (traitement == null)
            {
                return NotFound();
            }
            ViewData["AnimalId"] = new SelectList(_context.Animal, "Id", "Id", traitement.AnimalId);
            return View(traitement);
        }

        // POST: Traitements/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,AnimalId,TypeTraitement,Medicament,DateTraitement,DateProchainTraitement,Notes")] Traitement traitement)
        {
            if (id != traitement.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(traitement);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TraitementExists(traitement.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AnimalId"] = new SelectList(_context.Animal, "Id", "Id", traitement.AnimalId);
            return View(traitement);
        }

        // GET: Traitements/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var traitement = await _context.Traitement
                .Include(t => t.Animal)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (traitement == null)
            {
                return NotFound();
            }

            return View(traitement);
        }

        // POST: Traitements/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var traitement = await _context.Traitement.FindAsync(id);
            if (traitement != null)
            {
                _context.Traitement.Remove(traitement);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TraitementExists(int id)
        {
            return _context.Traitement.Any(e => e.Id == id);
        }
    }
}
