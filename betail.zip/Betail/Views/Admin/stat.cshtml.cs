using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Betail.Views.Admin
{
    public class statModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
