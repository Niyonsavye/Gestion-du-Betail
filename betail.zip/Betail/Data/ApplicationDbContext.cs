﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Betail.Models;

namespace Betail.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Betail.Models.Animal> Animal { get; set; } = default!;
        public DbSet<Betail.Models.Employee> Employee { get; set; } = default!;
        public DbSet<Feeding> Feeding { get; set; } = default!;
        public DbSet<Betail.Models.Finance> Finance { get; set; } = default!;
        public DbSet<Betail.Models.Traitement> Traitement { get; set; } = default!;
        public DbSet<Betail.Models.TypeAnimal> TypeAnimal { get; set; } = default!;
        public DbSet<Betail.Models.Vaccination> Vaccination { get; set; } = default!;
    }
}
